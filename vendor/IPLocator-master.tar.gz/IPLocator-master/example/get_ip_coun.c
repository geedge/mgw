#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include "../include/maxminddb.h"

#define xdebug(fmt, arg...) 					\
	do{											\
		printf("%s %d : ", __FILE__, __LINE__);	\
		printf(fmt, ##arg);						\
		printf("\n");							\
	}while(0)

/*
 *	Query the COUNTRY field of an IP address in mmdb file.
 */

int main(int argc, char **argv)
{
	if(argc < 2)
	{
		xdebug("Usage : %s dbfilename IP", argv[0]);
		return 0;
	}

	char *filename = argv[1];	// mmdb file path
	char *ip_address = argv[2];	// input IP address

	MMDB_s mmdb;
	int status = MMDB_open(filename, MMDB_MODE_MMAP, &mmdb);

	if(MMDB_SUCCESS != status)
	{
		fprintf(stderr, "\n  Can't open %s - %s\n",
				filename, MMDB_strerror(status));

		if(MMDB_IO_ERROR == status)
		{
			fprintf(stderr, "IO error: %s\n", strerror(errno));
		}
		exit(1);
	}

	int gai_error, mmdb_error;
	
	MMDB_lookup_result_s result =
		MMDB_lookup_string(&mmdb, ip_address, &gai_error, &mmdb_error);

	if (0 != gai_error)
	{
		fprintf(stderr,
				"\n  Error from getaddrinfo for %s - %s\n\n",
				ip_address, gai_strerror(gai_error));
		exit(2);
	}

	if (MMDB_SUCCESS != mmdb_error)
	{
		fprintf(stderr,
				"\n  Got an error from libmaxminddb: %s\n\n",
				MMDB_strerror(mmdb_error));
		exit(3);
	}

	MMDB_entry_data_s entry_data;

	int exit_code = 0;
	if (result.found_entry)
	{

		int status = MMDB_get_value(&result.entry, &entry_data, "COUNTRY", NULL);

		if (MMDB_SUCCESS != status)
		{
			fprintf(
					stderr,
					"Got an error looking up the entry data - %s\n",
					MMDB_strerror(status));
			exit_code = 4;
			goto end;
		}

		if (entry_data.has_data)
		{
			char *name_en = malloc(sizeof(entry_data.data_size + 1));
			memset(name_en, '\0', sizeof(entry_data.data_size + 1));
			memcpy(name_en, entry_data.utf8_string, entry_data.data_size);

			printf ("%s\n", name_en);
			free(name_en);
			name_en = NULL;
		}
	} 
	else
	{
		fprintf(
				stderr,
				"\n  No entry for this IP address (%s) was found\n\n",
				ip_address);
		exit_code = 5;
	}

end:
	MMDB_close(&mmdb);
	exit(exit_code);
}
