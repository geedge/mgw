### 简介

IPLocator是基于Maxmind的IP定位库。包括mmdb IP库文件和libmaxmind读取文件接口。

### 安装

运行以下指令以安装libmaxmind，生成的libmaxminddb.so及libmaxminddb.a位于/usr/local/lib下。

	$ ./configure
	$ make
	$ make check
	$ sudo make install
	$ sudo ldconfig

configure 脚本可使用 `--prefix` 参数自定义文件的安装位置。详细信息可参考 `./configure --help`。

#### 安装过程中可能出现的问题： 

*	make stops with WARNING: `'aclocal-1.15' is missing on your system.`，触发重新构建。  
	尝试运行以下任一条指令：

	```
	$ autoreconf -f -i
	$ touch * 
	```

*	make check tests failed: `./compile_c++_t.pl: Permission denied` .  
	确认 perl 脚本可执行：

	```
	$ cd ./t
	$ chomd +x *.pl
	```

*	after installing, receive an error: `libmaxminddb.so.0 is missing.`  
	需要将前缀中的 lib 目录添加到库路径。使用默认前缀时 (`/usr/local`)，运行以下指令：  

	```
	$ sudo sh -c "echo /usr/local/lib  >> /etc/ld.so.conf.d/local.conf"
	$ ldconfig
	```


### 对外接口

libmaxmind 接口详细介绍见 ./doc/libmaxminddb.md.

### 库文件格式

查询接口以类JSON结构读取mmdb文件内容。以完整版库文件为例，查询一条 202.43.148.189 IP记录包含以下字段：

```JSON
  {
	"AREA_CODE":
	  "100006" <utf8_string>
	"ASN":
	  "4808_4847" <utf8_string>
	"CITY":
	  "Beijing" <utf8_string>
	"COUNTRY":
	  "China" <utf8_string>
	"ISP":
	  "-" <utf8_string>
	"LATITUDE":
	  39.907501 <float>
	"LONGITUDE":
	  116.397003 <float>
	"PROVINCE":
	  "Beijing" <utf8_string>
  }
```

### 库文件版本

v4与v6库各提供三种不同版本的库文件，以满足不同需求：

*	all_ip_info_v4(6).mmdb: 完整版，包含所有字段。
*	all_ip_only_coun_v4(6).mmdb: 仅包含国家字段。
*	Kazakhstan_v4(6).mmdb: K国完整，其他仅含国家和ASN。

### 示例程序

*	查询IP所有字段
```c
	MMDB_entry_data_list_s *entry_data_list = NULL;
	int status = MMDB_get_entry_data_list(&result.entry, &entry_data_list);
	MMDB_dump_entry_data_list(stdout, entry_data_list, 2);
```

*	查询IP对应COUNTRY字段
```c
	MMDB_entry_data_s entry_data;
	int status = MMDB_get_value(&result.entry, &entry_data, "COUNTRY", NULL);
```

